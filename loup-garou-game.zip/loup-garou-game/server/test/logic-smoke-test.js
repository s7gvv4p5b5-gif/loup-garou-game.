// test/logic-smoke-test.js
// Petit test automatisé, sans réseau ni navigateur : il simule une partie
// complète (lobby -> nuits -> votes -> victoire) directement sur le moteur
// de jeu (Room.js) pour vérifier que la logique ne plante pas et aboutit
// bien à une victoire. Lancer avec : node test/logic-smoke-test.js

const path = require('path');
const Room = require(path.join(__dirname, '..', 'Room'));

const fakeIo = { to: () => ({ emit: () => {} }) }; // on ignore les émissions socket ici

function assert(cond, message) {
  if (!cond) throw new Error('❌ ' + message);
}

function firstAlive(room, predicate, excludeToken) {
  return [...room.players.values()].find(p => p.alive && predicate(p) && p.token !== excludeToken);
}

function run() {
  const room = new Room('TEST', fakeIo);
  const names = ['Alice', 'Bilal', 'Chloé', 'Diego', 'Emma', 'Farid', 'Gaïa'];
  const tokens = names.map((name, i) => {
    const token = 't' + i;
    room.addPlayer(name, token, 's' + i);
    return token;
  });

  tokens.forEach(t => room.toggleReady(t));
  room.startGame(tokens[0]);
  assert(room.phase === 'night', 'La partie doit démarrer en phase de nuit');
  console.log(`Rôles distribués sur ${tokens.length} joueurs :`,
    [...room.players.values()].map(p => `${p.pseudo}=${p.role}`).join(', '));

  let rounds = 0;
  while (room.phase !== 'ended' && rounds < 20) {
    rounds++;

    if (room.phase === 'night') {
      if (room.currentNightStep === 'voyante') {
        const seer = firstAlive(room, p => p.role === 'voyante');
        const target = firstAlive(room, () => true, seer.token);
        room.submitVoyanteAction(seer.token, target.token);
      }
      if (room.phase === 'night' && room.currentNightStep === 'loups') {
        const wolves = [...room.players.values()].filter(p => p.alive && p.role === 'loup_garou');
        const victim = firstAlive(room, p => p.role !== 'loup_garou');
        wolves.forEach(w => { if (room.phase === 'night') room.submitWolfVote(w.token, victim.token); });
      }
      if (room.phase === 'night' && room.currentNightStep === 'sorciere') {
        const witch = firstAlive(room, p => p.role === 'sorciere');
        if (witch) room.submitSorciereAction(witch.token, {});
      }
    } else if (room.phase === 'hunter_shot') {
      const shooter = room.pendingHunterShot;
      const target = firstAlive(room, () => true, shooter);
      if (target) room.submitHunterShot(shooter, target.token);
    } else if (room.phase === 'day_reveal') {
      const host = [...room.players.values()].find(p => p.isHost);
      room.hostAdvance(host.token); // -> discussion
      room.startVote(); // on saute le minuteur de discussion pour le test
    } else if (room.phase === 'vote') {
      const wolfTarget = firstAlive(room, p => p.role === 'loup_garou');
      const alive = [...room.players.values()].filter(p => p.alive);
      alive.forEach(p => { if (room.phase === 'vote') room.submitVote(p.token, (wolfTarget || alive[0]).token); });
    } else if (room.phase === 'vote_reveal') {
      const host = [...room.players.values()].find(p => p.isHost);
      room.hostAdvance(host.token); // -> nuit suivante
    }
  }

  assert(room.phase === 'ended', `La partie doit se terminer (phase finale: ${room.phase})`);
  assert(['village', 'loups'].includes(room.winner), 'Un camp doit avoir gagné');
  console.log(`✅ Partie terminée en ${rounds} étapes — camp vainqueur : ${room.winner}`);
  console.log('✅ Test de logique réussi.');
}

run();
